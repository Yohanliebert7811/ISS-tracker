import React, { useEffect, useState } from 'react';
import { Globe, MapPin, Clock, Gauge } from 'lucide-react';
import { ISSPosition } from '../types/iss';
import { fetchISSPosition } from '../services/issApi';

export const ISSTracker: React.FC = () => {
  const [issPosition, setIssPosition] = useState<ISSPosition | null>(null);
  const [loading, setLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  useEffect(() => {
    const updateISSPosition = async () => {
      try {
        const position = await fetchISSPosition();
        setIssPosition(position);
        setLastUpdate(new Date());
        setLoading(false);
      } catch (error) {
        console.error('Failed to fetch ISS position:', error);
        setLoading(false);
      }
    };

    updateISSPosition();
    const interval = setInterval(updateISSPosition, 5000);

    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-8">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-400"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-8 transition-all duration-300 hover:border-white/20">
      <div className="flex items-center space-x-3 mb-6">
        <Globe className="h-6 w-6 text-blue-400" />
        <h2 className="text-2xl font-semibold">International Space Station</h2>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-sm text-green-400">Live</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white/5 rounded-xl p-4 border border-white/10">
          <div className="flex items-center space-x-2 mb-2">
            <MapPin className="h-4 w-4 text-blue-400" />
            <span className="text-sm text-gray-300">Latitude</span>
          </div>
          <div className="text-2xl font-bold text-white">
            {issPosition?.latitude ? `${parseFloat(issPosition.latitude).toFixed(4)}°` : 'N/A'}
          </div>
        </div>

        <div className="bg-white/5 rounded-xl p-4 border border-white/10">
          <div className="flex items-center space-x-2 mb-2">
            <MapPin className="h-4 w-4 text-purple-400" />
            <span className="text-sm text-gray-300">Longitude</span>
          </div>
          <div className="text-2xl font-bold text-white">
            {issPosition?.longitude ? `${parseFloat(issPosition.longitude).toFixed(4)}°` : 'N/A'}
          </div>
        </div>

        <div className="bg-white/5 rounded-xl p-4 border border-white/10">
          <div className="flex items-center space-x-2 mb-2">
            <Gauge className="h-4 w-4 text-orange-400" />
            <span className="text-sm text-gray-300">Altitude</span>
          </div>
          <div className="text-2xl font-bold text-white">
            ~408 km
          </div>
        </div>

        <div className="bg-white/5 rounded-xl p-4 border border-white/10">
          <div className="flex items-center space-x-2 mb-2">
            <Clock className="h-4 w-4 text-green-400" />
            <span className="text-sm text-gray-300">Speed</span>
          </div>
          <div className="text-2xl font-bold text-white">
            27,600 km/h
          </div>
        </div>
      </div>

      <div className="mt-6 pt-6 border-t border-white/10">
        <div className="flex items-center justify-between text-sm text-gray-400">
          <span>Last updated: {lastUpdate.toLocaleTimeString()}</span>
          <span>Orbital period: ~93 minutes</span>
        </div>
      </div>
    </div>
  );
};
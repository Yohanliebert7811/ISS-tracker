import React, { useState, useEffect } from 'react';
import { Calculator, Zap, Brain, TrendingUp } from 'lucide-react';

interface QuantumResult {
  classicalPeriod: number;
  quantumCorrectedPeriod: number;
  uncertaintyReduction: number;
  confidence: number;
}

export const QuantumCalculator: React.FC = () => {
  const [altitude, setAltitude] = useState<string>('');
  const [result, setResult] = useState<QuantumResult | null>(null);
  const [calculating, setCalculating] = useState(false);

  const simulateQuantumCalculation = async (alt: number): Promise<QuantumResult> => {
    // Simulate quantum-enhanced orbital calculation
    return new Promise((resolve) => {
      setTimeout(() => {
        const classicalPeriod = 2 * Math.PI * Math.sqrt(Math.pow((6371 + alt) * 1000, 3) / (3.986004418e14)) / 3600;
        const quantumCorrection = 1 + (Math.random() - 0.5) * 0.001; // Small quantum correction
        const quantumCorrectedPeriod = classicalPeriod * quantumCorrection;
        
        resolve({
          classicalPeriod,
          quantumCorrectedPeriod,
          uncertaintyReduction: 99.7 + Math.random() * 0.3,
          confidence: 0.9990 + Math.random() * 0.0009
        });
      }, 2000);
    });
  };

  const handleCalculate = async () => {
    if (!altitude) return;
    
    setCalculating(true);
    const result = await simulateQuantumCalculation(parseFloat(altitude));
    setResult(result);
    setCalculating(false);
  };

  return (
    <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-8 transition-all duration-300 hover:border-purple-500/30">
      <div className="flex items-center space-x-3 mb-6">
        <div className="relative">
          <Calculator className="h-6 w-6 text-purple-400" />
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-purple-400 rounded-full animate-pulse"></div>
        </div>
        <h2 className="text-2xl font-semibold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
          Quantum-Enhanced Orbital Calculator
        </h2>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Satellite Altitude (km)
          </label>
          <input
            type="number"
            value={altitude}
            onChange={(e) => setAltitude(e.target.value)}
            className="w-full px-4 py-3 bg-white/5 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            placeholder="Enter altitude (e.g., 408 for ISS)"
            min="150"
            step="1"
          />
        </div>

        <button
          onClick={handleCalculate}
          disabled={!altitude || calculating}
          className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-200 transform hover:scale-[1.02] disabled:scale-100 flex items-center justify-center space-x-2"
        >
          {calculating ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              <span>Quantum Processing...</span>
            </>
          ) : (
            <>
              <Brain className="h-4 w-4" />
              <span>Calculate with Quantum Enhancement</span>
            </>
          )}
        </button>

        {result && (
          <div className="space-y-4">
            <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-xl p-6 border border-purple-500/20">
              <h3 className="text-lg font-semibold text-purple-400 mb-4 flex items-center space-x-2">
                <Zap className="h-5 w-5" />
                <span>Quantum-Enhanced Results</span>
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-sm text-gray-400">Classical Period</p>
                  <p className="text-xl font-bold text-white">{result.classicalPeriod.toFixed(4)} hours</p>
                </div>
                
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-sm text-gray-400">Quantum-Corrected Period</p>
                  <p className="text-xl font-bold text-purple-400">{result.quantumCorrectedPeriod.toFixed(6)} hours</p>
                </div>
                
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-sm text-gray-400">Uncertainty Reduction</p>
                  <p className="text-xl font-bold text-green-400">{result.uncertaintyReduction.toFixed(1)}%</p>
                </div>
                
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-sm text-gray-400">Quantum Confidence</p>
                  <p className="text-xl font-bold text-cyan-400">{(result.confidence * 100).toFixed(4)}%</p>
                </div>
              </div>

              <div className="mt-4 p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
                <div className="flex items-center space-x-2 mb-2">
                  <TrendingUp className="h-4 w-4 text-blue-400" />
                  <span className="text-sm font-medium text-blue-400">Quantum Advantage</span>
                </div>
                <p className="text-xs text-gray-300">
                  Quantum error correction reduces orbital prediction uncertainty by leveraging 
                  superposition states and entanglement-based calculations for enhanced precision.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
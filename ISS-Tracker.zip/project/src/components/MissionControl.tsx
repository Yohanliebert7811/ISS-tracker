import React, { Suspense } from 'react';
import { Earth3D } from './Earth3D';
import { TelemetryPanel } from './TelemetryPanel';
import { SpaceWeather } from './SpaceWeather';
import { AlertsPanel } from './AlertsPanel';

export const MissionControl: React.FC = () => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[calc(100vh-200px)]">
      {/* Main 3D Visualization */}
      <div className="lg:col-span-3 bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">3D Earth Visualization</h2>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-sm text-green-400">Real-time</span>
          </div>
        </div>
        <div className="h-full rounded-xl overflow-hidden bg-black/30">
          <Suspense fallback={
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-400"></div>
            </div>
          }>
            <Earth3D />
          </Suspense>
        </div>
      </div>

      {/* Control Panels */}
      <div className="flex flex-col space-y-4">
        <TelemetryPanel />
        <SpaceWeather />
        <AlertsPanel />
      </div>
    </div>
  );
};
import React, { useState, useEffect } from 'react';
import { Shield, Check, Clock, Hash } from 'lucide-react';

interface DataBlock {
  id: string;
  timestamp: number;
  dataType: string;
  hash: string;
  verified: boolean;
  confidence: number;
}

export const BlockchainVerification: React.FC = () => {
  const [blocks, setBlocks] = useState<DataBlock[]>([]);
  const [totalVerified, setTotalVerified] = useState(0);

  useEffect(() => {
    const generateBlocks = () => {
      const dataTypes = ['ISS Position', 'APOD Data', 'Space Weather', 'Orbital Calculation'];
      const newBlocks: DataBlock[] = [];

      for (let i = 0; i < 5; i++) {
        newBlocks.push({
          id: `block_${Date.now()}_${i}`,
          timestamp: Date.now() - (i * 30000),
          dataType: dataTypes[Math.floor(Math.random() * dataTypes.length)],
          hash: `0x${Math.random().toString(16).substr(2, 8)}...${Math.random().toString(16).substr(2, 8)}`,
          verified: Math.random() > 0.1,
          confidence: 95 + Math.random() * 5
        });
      }

      setBlocks(newBlocks);
      setTotalVerified(newBlocks.filter(b => b.verified).length);
    };

    generateBlocks();
    const interval = setInterval(generateBlocks, 15000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-6 transition-all duration-300 hover:border-green-500/30">
      <div className="flex items-center space-x-3 mb-6">
        <div className="relative">
          <Shield className="h-6 w-6 text-green-400" />
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
        </div>
        <h2 className="text-xl font-semibold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
          Blockchain Data Verification
        </h2>
      </div>

      {/* Verification Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-white/5 rounded-xl p-3 border border-white/10 text-center">
          <div className="text-2xl font-bold text-green-400">{totalVerified}</div>
          <div className="text-xs text-gray-400">Verified Blocks</div>
        </div>
        <div className="bg-white/5 rounded-xl p-3 border border-white/10 text-center">
          <div className="text-2xl font-bold text-blue-400">99.8%</div>
          <div className="text-xs text-gray-400">Integrity Score</div>
        </div>
        <div className="bg-white/5 rounded-xl p-3 border border-white/10 text-center">
          <div className="text-2xl font-bold text-purple-400">2.3s</div>
          <div className="text-xs text-gray-400">Avg Verify Time</div>
        </div>
      </div>

      {/* Recent Blocks */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-white mb-3">Recent Data Blocks</h3>
        {blocks.map((block) => (
          <div
            key={block.id}
            className={`p-3 rounded-xl border transition-all duration-200 ${
              block.verified 
                ? 'bg-green-500/10 border-green-500/30' 
                : 'bg-yellow-500/10 border-yellow-500/30'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {block.verified ? (
                  <Check className="h-4 w-4 text-green-400" />
                ) : (
                  <Clock className="h-4 w-4 text-yellow-400 animate-spin" />
                )}
                <div>
                  <div className="text-sm font-medium text-white">{block.dataType}</div>
                  <div className="flex items-center space-x-2 text-xs text-gray-400">
                    <Hash className="h-3 w-3" />
                    <span>{block.hash}</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-semibold text-green-400">
                  {block.confidence.toFixed(1)}%
                </div>
                <div className="text-xs text-gray-400">
                  {new Date(block.timestamp).toLocaleTimeString()}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-white/10">
        <div className="text-xs text-gray-400 text-center">
          Decentralized verification network • IPFS distributed storage
        </div>
      </div>
    </div>
  );
};
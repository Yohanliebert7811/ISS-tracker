import React, { useState, useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Calculator, TrendingUp, Download, Zap } from 'lucide-react';
import { calculateOrbitPeriod } from '../utils/orbital';

interface OrbitData {
  altitude: number;
  period: number;
  velocity: number;
  energy: number;
}

export const OrbitAnalyzer: React.FC = () => {
  const [minAltitude, setMinAltitude] = useState(200);
  const [maxAltitude, setMaxAltitude] = useState(2000);
  const [selectedPoint, setSelectedPoint] = useState<OrbitData | null>(null);

  const orbitData = useMemo(() => {
    const data: OrbitData[] = [];
    const step = (maxAltitude - minAltitude) / 100;
    
    for (let alt = minAltitude; alt <= maxAltitude; alt += step) {
      const { period, velocity } = calculateOrbitPeriod(alt);
      const energy = -398600.4418 / (6371 + alt); // Specific orbital energy
      
      data.push({
        altitude: Math.round(alt),
        period: period,
        velocity: velocity,
        energy: energy
      });
    }
    
    return data;
  }, [minAltitude, maxAltitude]);

  const exportData = () => {
    const csvContent = [
      ['Altitude (km)', 'Period (hours)', 'Velocity (km/s)', 'Energy (MJ/kg)'],
      ...orbitData.map(d => [
        d.altitude.toString(),
        d.period.toFixed(3),
        d.velocity.toFixed(3),
        (d.energy / 1000000).toFixed(3)
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `orbit_analysis_${minAltitude}-${maxAltitude}km.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <Calculator className="h-6 w-6 text-purple-400" />
            <h2 className="text-2xl font-semibold">Orbital Analysis Suite</h2>
          </div>
          <button
            onClick={exportData}
            className="flex items-center space-x-2 bg-green-500/20 hover:bg-green-500/30 text-green-400 px-4 py-2 rounded-lg transition-colors duration-200"
          >
            <Download className="h-4 w-4" />
            <span>Export Data</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Minimum Altitude (km)
            </label>
            <input
              type="number"
              value={minAltitude}
              onChange={(e) => setMinAltitude(Number(e.target.value))}
              className="w-full px-4 py-3 bg-white/5 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              min="150"
              max="1000"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Maximum Altitude (km)
            </label>
            <input
              type="number"
              value={maxAltitude}
              onChange={(e) => setMaxAltitude(Number(e.target.value))}
              className="w-full px-4 py-3 bg-white/5 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              min="500"
              max="5000"
            />
          </div>
        </div>

        {selectedPoint && (
          <div className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 rounded-xl p-4 border border-purple-500/20 mb-6">
            <h3 className="text-lg font-semibold text-purple-400 mb-3">Selected Orbit Parameters</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-gray-400">Altitude</p>
                <p className="text-xl font-bold text-white">{selectedPoint.altitude} km</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Period</p>
                <p className="text-xl font-bold text-white">{selectedPoint.period.toFixed(2)} h</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Velocity</p>
                <p className="text-xl font-bold text-white">{selectedPoint.velocity.toFixed(2)} km/s</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Energy</p>
                <p className="text-xl font-bold text-white">{(selectedPoint.energy / 1000000).toFixed(1)} MJ/kg</p>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <TrendingUp className="h-5 w-5 text-blue-400" />
            <h3 className="text-lg font-semibold">Orbital Period vs Altitude</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={orbitData} onClick={(data) => data?.activePayload?.[0] && setSelectedPoint(data.activePayload[0].payload)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis 
                dataKey="altitude" 
                stroke="#9CA3AF"
                label={{ value: 'Altitude (km)', position: 'insideBottom', offset: -5 }}
              />
              <YAxis 
                stroke="#9CA3AF"
                label={{ value: 'Period (hours)', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1F2937', 
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#F9FAFB'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="period" 
                stroke="#3B82F6" 
                strokeWidth={2}
                dot={{ fill: '#3B82F6', strokeWidth: 2, r: 3 }}
                activeDot={{ r: 6, stroke: '#3B82F6', strokeWidth: 2 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <Zap className="h-5 w-5 text-orange-400" />
            <h3 className="text-lg font-semibold">Orbital Velocity vs Altitude</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={orbitData} onClick={(data) => data?.activePayload?.[0] && setSelectedPoint(data.activePayload[0].payload)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis 
                dataKey="altitude" 
                stroke="#9CA3AF"
                label={{ value: 'Altitude (km)', position: 'insideBottom', offset: -5 }}
              />
              <YAxis 
                stroke="#9CA3AF"
                label={{ value: 'Velocity (km/s)', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1F2937', 
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#F9FAFB'
                }}
              />
              <Area 
                type="monotone" 
                dataKey="velocity" 
                stroke="#F59E0B" 
                fill="url(#velocityGradient)"
                strokeWidth={2}
              />
              <defs>
                <linearGradient id="velocityGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#F59E0B" stopOpacity={0}/>
                </linearGradient>
              </defs>
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
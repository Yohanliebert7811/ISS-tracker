import React, { useState, useEffect } from 'react';
import { Brain, Zap, Shield, AlertTriangle, TrendingUp } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface SpaceWeatherPrediction {
  timestamp: number;
  solarFlareRisk: number;
  geomagneticStorm: number;
  radiationLevel: number;
  aiConfidence: number;
}

export const AISpaceWeather: React.FC = () => {
  const [predictions, setPredictions] = useState<SpaceWeatherPrediction[]>([]);
  const [currentRisk, setCurrentRisk] = useState({
    solarFlare: 2,
    geomagnetic: 1,
    radiation: 3,
    aiConfidence: 94.7
  });

  useEffect(() => {
    // Generate AI-predicted space weather data
    const generatePredictions = () => {
      const now = Date.now();
      const data: SpaceWeatherPrediction[] = [];
      
      for (let i = 0; i < 24; i++) {
        data.push({
          timestamp: now + (i * 60 * 60 * 1000), // Next 24 hours
          solarFlareRisk: Math.max(0, Math.min(5, 2 + Math.sin(i * 0.3) + Math.random() * 0.5)),
          geomagneticStorm: Math.max(0, Math.min(5, 1.5 + Math.cos(i * 0.2) + Math.random() * 0.3)),
          radiationLevel: Math.max(0, Math.min(5, 2.5 + Math.sin(i * 0.4) * 0.5 + Math.random() * 0.4)),
          aiConfidence: 85 + Math.random() * 15
        });
      }
      
      setPredictions(data);
    };

    generatePredictions();
    const interval = setInterval(generatePredictions, 30000);
    return () => clearInterval(interval);
  }, []);

  const getRiskColor = (level: number) => {
    if (level <= 1.5) return 'text-green-400';
    if (level <= 3) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getRiskBg = (level: number) => {
    if (level <= 1.5) return 'bg-green-500/20 border-green-500/30';
    if (level <= 3) return 'bg-yellow-500/20 border-yellow-500/30';
    return 'bg-red-500/20 border-red-500/30';
  };

  return (
    <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-6 transition-all duration-300 hover:border-white/20">
      <div className="flex items-center space-x-3 mb-6">
        <div className="relative">
          <Brain className="h-6 w-6 text-cyan-400" />
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-cyan-400 rounded-full animate-pulse"></div>
        </div>
        <h2 className="text-xl font-semibold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
          AI Space Weather Forecast
        </h2>
      </div>

      {/* Current Conditions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className={`rounded-xl p-4 border ${getRiskBg(currentRisk.solarFlare)}`}>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Zap className="h-4 w-4 text-yellow-400" />
              <span className="text-sm text-gray-300">Solar Flares</span>
            </div>
            <span className={`text-sm font-semibold ${getRiskColor(currentRisk.solarFlare)}`}>
              Level {currentRisk.solarFlare.toFixed(1)}
            </span>
          </div>
          <div className="flex space-x-1">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className={`h-2 flex-1 rounded ${
                  i < currentRisk.solarFlare ? 'bg-yellow-400' : 'bg-gray-600'
                }`}
              ></div>
            ))}
          </div>
        </div>

        <div className={`rounded-xl p-4 border ${getRiskBg(currentRisk.geomagnetic)}`}>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Shield className="h-4 w-4 text-blue-400" />
              <span className="text-sm text-gray-300">Geomagnetic</span>
            </div>
            <span className={`text-sm font-semibold ${getRiskColor(currentRisk.geomagnetic)}`}>
              Level {currentRisk.geomagnetic.toFixed(1)}
            </span>
          </div>
          <div className="flex space-x-1">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className={`h-2 flex-1 rounded ${
                  i < currentRisk.geomagnetic ? 'bg-blue-400' : 'bg-gray-600'
                }`}
              ></div>
            ))}
          </div>
        </div>

        <div className={`rounded-xl p-4 border ${getRiskBg(currentRisk.radiation)}`}>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-4 w-4 text-red-400" />
              <span className="text-sm text-gray-300">Radiation</span>
            </div>
            <span className={`text-sm font-semibold ${getRiskColor(currentRisk.radiation)}`}>
              Level {currentRisk.radiation.toFixed(1)}
            </span>
          </div>
          <div className="flex space-x-1">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className={`h-2 flex-1 rounded ${
                  i < currentRisk.radiation ? 'bg-red-400' : 'bg-gray-600'
                }`}
              ></div>
            ))}
          </div>
        </div>
      </div>

      {/* AI Confidence */}
      <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-xl p-4 border border-cyan-500/20 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <TrendingUp className="h-4 w-4 text-cyan-400" />
            <span className="text-sm text-gray-300">AI Prediction Confidence</span>
          </div>
          <span className="text-lg font-bold text-cyan-400">{currentRisk.aiConfidence}%</span>
        </div>
        <div className="mt-2 w-full bg-gray-700 rounded-full h-2">
          <div 
            className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full transition-all duration-500"
            style={{ width: `${currentRisk.aiConfidence}%` }}
          ></div>
        </div>
      </div>

      {/* 24-Hour Forecast Chart */}
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-white mb-3 flex items-center space-x-2">
          <Brain className="h-5 w-5 text-cyan-400" />
          <span>24-Hour AI Forecast</span>
        </h3>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={predictions}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis 
              dataKey="timestamp" 
              stroke="#9CA3AF"
              tickFormatter={(value) => new Date(value).getHours() + 'h'}
            />
            <YAxis stroke="#9CA3AF" domain={[0, 5]} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1F2937', 
                border: '1px solid #374151',
                borderRadius: '8px',
                color: '#F9FAFB'
              }}
              labelFormatter={(value) => new Date(value).toLocaleTimeString()}
            />
            <Line 
              type="monotone" 
              dataKey="solarFlareRisk" 
              stroke="#F59E0B" 
              strokeWidth={2}
              name="Solar Flare Risk"
            />
            <Line 
              type="monotone" 
              dataKey="geomagneticStorm" 
              stroke="#3B82F6" 
              strokeWidth={2}
              name="Geomagnetic Storm"
            />
            <Line 
              type="monotone" 
              dataKey="radiationLevel" 
              stroke="#EF4444" 
              strokeWidth={2}
              name="Radiation Level"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="text-xs text-gray-400 text-center">
        Powered by Neural Space Weather Network • Updated every 30 seconds
      </div>
    </div>
  );
};
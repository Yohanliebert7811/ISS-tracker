import React, { useEffect, useState } from 'react';
import { Camera, Calendar, User, ExternalLink } from 'lucide-react';
import { APODData } from '../types/nasa';
import { fetchAPOD } from '../services/nasaApi';

export const APODSection: React.FC = () => {
  const [apod, setApod] = useState<APODData | null>(null);
  const [loading, setLoading] = useState(true);
  const [imageLoaded, setImageLoaded] = useState(false);

  useEffect(() => {
    const loadAPOD = async () => {
      try {
        const data = await fetchAPOD();
        setApod(data);
      } catch (error) {
        console.error('Failed to fetch APOD:', error);
        // Fallback data
        setApod({
          title: 'Earth from Space',
          url: 'https://images.pexels.com/photos/87009/earth-blue-planet-globe-planet-87009.jpeg',
          explanation: 'A stunning view of our home planet from the International Space Station.',
          date: new Date().toISOString().split('T')[0],
          media_type: 'image'
        });
      } finally {
        setLoading(false);
      }
    };

    loadAPOD();
  }, []);

  if (loading) {
    return (
      <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-8">
        <div className="animate-pulse">
          <div className="h-6 bg-white/10 rounded mb-4"></div>
          <div className="h-64 bg-white/10 rounded-xl mb-4"></div>
          <div className="space-y-2">
            <div className="h-4 bg-white/10 rounded"></div>
            <div className="h-4 bg-white/10 rounded w-3/4"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-8 transition-all duration-300 hover:border-white/20">
      <div className="flex items-center space-x-3 mb-6">
        <Camera className="h-6 w-6 text-purple-400" />
        <h2 className="text-2xl font-semibold">Astronomy Picture of the Day</h2>
      </div>

      {apod && (
        <div className="space-y-4">
          <div className="relative group overflow-hidden rounded-xl">
            <img
              src={apod.url}
              alt={apod.title}
              className={`w-full h-64 object-cover transition-all duration-500 ${
                imageLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
              }`}
              onLoad={() => setImageLoaded(true)}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <ExternalLink className="h-5 w-5 text-white" />
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-xl font-semibold text-white leading-tight">
              {apod.title}
            </h3>
            
            <div className="flex items-center space-x-4 text-sm text-gray-400">
              <div className="flex items-center space-x-1">
                <Calendar className="h-4 w-4" />
                <span>{apod.date}</span>
              </div>
              {apod.copyright && (
                <div className="flex items-center space-x-1">
                  <User className="h-4 w-4" />
                  <span>{apod.copyright}</span>
                </div>
              )}
            </div>

            <p className="text-gray-300 leading-relaxed text-sm line-clamp-4">
              {apod.explanation}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
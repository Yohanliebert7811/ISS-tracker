import React, { useState } from 'react';
import { Calculator, Download, Rocket } from 'lucide-react';
import { calculateOrbitPeriod } from '../utils/orbital';

interface Calculation {
  altitude: number;
  period: number;
  velocity: number;
  timestamp: Date;
}

export const OrbitCalculator: React.FC = () => {
  const [altitude, setAltitude] = useState<string>('');
  const [calculations, setCalculations] = useState<Calculation[]>([]);
  const [result, setResult] = useState<Calculation | null>(null);

  const handleCalculate = (e: React.FormEvent) => {
    e.preventDefault();
    
    const altitudeKm = parseFloat(altitude);
    if (isNaN(altitudeKm) || altitudeKm < 0) {
      return;
    }

    const { period, velocity } = calculateOrbitPeriod(altitudeKm);
    const calculation: Calculation = {
      altitude: altitudeKm,
      period,
      velocity,
      timestamp: new Date()
    };

    setResult(calculation);
    setCalculations(prev => [calculation, ...prev.slice(0, 9)]); // Keep last 10
  };

  const exportToCSV = () => {
    if (calculations.length === 0) return;

    const csvContent = [
      ['Altitude (km)', 'Orbital Period (hours)', 'Orbital Velocity (km/s)', 'Calculated At'],
      ...calculations.map(calc => [
        calc.altitude.toString(),
        calc.period.toFixed(2),
        calc.velocity.toFixed(2),
        calc.timestamp.toISOString()
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `orbital_calculations_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-8 transition-all duration-300 hover:border-white/20">
      <div className="flex items-center space-x-3 mb-6">
        <Calculator className="h-6 w-6 text-orange-400" />
        <h2 className="text-2xl font-semibold">Orbital Calculator</h2>
      </div>

      <form onSubmit={handleCalculate} className="space-y-4">
        <div>
          <label htmlFor="altitude" className="block text-sm font-medium text-gray-300 mb-2">
            Satellite Altitude (km)
          </label>
          <input
            type="number"
            id="altitude"
            value={altitude}
            onChange={(e) => setAltitude(e.target.value)}
            className="w-full px-4 py-3 bg-white/5 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
            placeholder="Enter altitude above Earth's surface"
            min="0"
            step="1"
            required
          />
          <p className="text-xs text-gray-400 mt-1">
            ISS orbits at approximately 408 km altitude
          </p>
        </div>

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-200 transform hover:scale-[1.02] flex items-center justify-center space-x-2"
        >
          <Rocket className="h-4 w-4" />
          <span>Calculate Orbit</span>
        </button>
      </form>

      {result && (
        <div className="mt-6 p-4 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-xl border border-blue-500/20">
          <h3 className="text-lg font-semibold text-blue-400 mb-3">Calculation Results</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-gray-400">Orbital Period</p>
              <p className="text-xl font-bold text-white">{result.period.toFixed(2)} hours</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Orbital Velocity</p>
              <p className="text-xl font-bold text-white">{result.velocity.toFixed(2)} km/s</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Altitude</p>
              <p className="text-xl font-bold text-white">{result.altitude} km</p>
            </div>
          </div>
        </div>
      )}

      {calculations.length > 0 && (
        <div className="mt-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Recent Calculations</h3>
            <button
              onClick={exportToCSV}
              className="flex items-center space-x-2 text-sm bg-green-500/20 hover:bg-green-500/30 text-green-400 px-3 py-2 rounded-lg transition-colors duration-200"
            >
              <Download className="h-4 w-4" />
              <span>Export CSV</span>
            </button>
          </div>
          
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {calculations.slice(0, 5).map((calc, index) => (
              <div key={index} className="flex justify-between items-center py-2 px-3 bg-white/5 rounded-lg text-sm">
                <span className="text-gray-300">{calc.altitude} km</span>
                <span className="text-blue-400">{calc.period.toFixed(2)}h</span>
                <span className="text-purple-400">{calc.velocity.toFixed(2)} km/s</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
import React, { useState } from 'react';
import { MapPin, Clock, Eye, Star } from 'lucide-react';

export const ISSPasses: React.FC = () => {
  const [location, setLocation] = useState({ latitude: '', longitude: '' });
  const [passes, setPasses] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const getPasses = async () => {
    if (!location.latitude || !location.longitude) return;
    
    setLoading(true);
    try {
      // Mock data for demonstration
      setPasses([
        {
          risetime: new Date(Date.now() + 2 * 60 * 60 * 1000),
          duration: 376,
          mag: -2.3
        },
        {
          risetime: new Date(Date.now() + 6 * 60 * 60 * 1000),
          duration: 423,
          duration: 423,
          mag: -1.8
        },
        {
          risetime: new Date(Date.now() + 12 * 60 * 60 * 1000),
          duration: 289,
          mag: -3.1
        }
      ]);
    } catch (error) {
      console.error('Failed to fetch ISS passes:', error);
    } finally {
      setLoading(false);
    }
  };

  const getCurrentLocation = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude.toFixed(4),
            longitude: position.coords.longitude.toFixed(4)
          });
        },
        (error) => {
          console.error('Geolocation error:', error);
        }
      );
    }
  };

  return (
    <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-8 transition-all duration-300 hover:border-white/20">
      <div className="flex items-center space-x-3 mb-6">
        <Eye className="h-6 w-6 text-green-400" />
        <h2 className="text-2xl font-semibold">ISS Pass Predictions</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Latitude
          </label>
          <input
            type="number"
            value={location.latitude}
            onChange={(e) => setLocation(prev => ({ ...prev, latitude: e.target.value }))}
            className="w-full px-4 py-3 bg-white/5 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
            placeholder="Your latitude"
            step="0.0001"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Longitude
          </label>
          <input
            type="number"
            value={location.longitude}
            onChange={(e) => setLocation(prev => ({ ...prev, longitude: e.target.value }))}
            className="w-full px-4 py-3 bg-white/5 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
            placeholder="Your longitude"
            step="0.0001"
          />
        </div>
      </div>

      <div className="flex space-x-4 mb-6">
        <button
          onClick={getCurrentLocation}
          className="flex items-center space-x-2 bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 px-4 py-2 rounded-lg transition-colors duration-200"
        >
          <MapPin className="h-4 w-4" />
          <span>Use My Location</span>
        </button>
        
        <button
          onClick={getPasses}
          disabled={loading || !location.latitude || !location.longitude}
          className="flex items-center space-x-2 bg-green-500/20 hover:bg-green-500/30 text-green-400 px-4 py-2 rounded-lg transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Star className="h-4 w-4" />
          <span>{loading ? 'Loading...' : 'Get Pass Times'}</span>
        </button>
      </div>

      {passes.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-green-400">Upcoming Visible Passes</h3>
          {passes.map((pass, index) => (
            <div key={index} className="bg-white/5 rounded-xl p-4 border border-white/10">
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <Clock className="h-4 w-4 text-blue-400" />
                    <span className="text-white font-semibold">
                      {pass.risetime.toLocaleString()}
                    </span>
                  </div>
                  <p className="text-sm text-gray-400">
                    Duration: {Math.floor(pass.duration / 60)} minutes {pass.duration % 60} seconds
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-orange-400 font-semibold">
                    Magnitude: {pass.mag}
                  </div>
                  <p className="text-xs text-gray-400">
                    {pass.mag < -2 ? 'Very Bright' : pass.mag < -1 ? 'Bright' : 'Visible'}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {passes.length === 0 && location.latitude && location.longitude && !loading && (
        <div className="text-center py-8 text-gray-400">
          <Star className="h-12 w-12 mx-auto mb-3 opacity-50" />
          <p>Click "Get Pass Times" to see when the ISS will be visible from your location</p>
        </div>
      )}
    </div>
  );
};
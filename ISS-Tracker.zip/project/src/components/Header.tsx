import React from 'react';
import { Satellite, Rocket } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="relative bg-black/20 backdrop-blur-md border-b border-white/10">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Satellite className="h-8 w-8 text-blue-400 animate-pulse" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-ping"></div>
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                ISS Mission Control
              </h1>
              <p className="text-sm text-gray-300">Live Space Station Monitoring Dashboard</p>
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-sm text-gray-300">ISS Online</span>
            </div>
            <div className="flex items-center space-x-2">
              <Rocket className="h-4 w-4 text-orange-400" />
              <span className="text-sm text-gray-300">Mission Active</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
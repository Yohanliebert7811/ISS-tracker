import React, { useState, useEffect } from 'react';
import { Sun, Zap, Shield, AlertTriangle } from 'lucide-react';

interface SpaceWeatherData {
  solarFlareLevel: number;
  geomagneticStorm: number;
  radiationLevel: number;
  kpIndex: number;
  solarWindSpeed: number;
}

export const SpaceWeather: React.FC = () => {
  const [weather, setWeather] = useState<SpaceWeatherData>({
    solarFlareLevel: 2,
    geomagneticStorm: 1,
    radiationLevel: 3,
    kpIndex: 2.5,
    solarWindSpeed: 450
  });

  useEffect(() => {
    const updateWeather = () => {
      setWeather({
        solarFlareLevel: Math.floor(Math.random() * 5) + 1,
        geomagneticStorm: Math.floor(Math.random() * 5) + 1,
        radiationLevel: Math.floor(Math.random() * 5) + 1,
        kpIndex: Math.random() * 9,
        solarWindSpeed: 300 + Math.random() * 400
      });
    };

    const interval = setInterval(updateWeather, 30000);
    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (level: number) => {
    if (level <= 2) return 'text-green-400';
    if (level <= 3) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getStatusText = (level: number) => {
    if (level <= 2) return 'Low';
    if (level <= 3) return 'Moderate';
    return 'High';
  };

  return (
    <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-6 transition-all duration-300 hover:border-white/20">
      <div className="flex items-center space-x-3 mb-6">
        <Sun className="h-6 w-6 text-yellow-400" />
        <h2 className="text-xl font-semibold">Space Weather</h2>
      </div>

      <div className="space-y-4">
        <div className="bg-white/5 rounded-xl p-4 border border-white/10">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Zap className="h-4 w-4 text-yellow-400" />
              <span className="text-sm text-gray-300">Solar Flares</span>
            </div>
            <span className={`text-sm font-semibold ${getStatusColor(weather.solarFlareLevel)}`}>
              {getStatusText(weather.solarFlareLevel)}
            </span>
          </div>
          <div className="flex space-x-1">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className={`h-2 flex-1 rounded ${
                  i < weather.solarFlareLevel ? 'bg-yellow-400' : 'bg-gray-600'
                }`}
              ></div>
            ))}
          </div>
        </div>

        <div className="bg-white/5 rounded-xl p-4 border border-white/10">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Shield className="h-4 w-4 text-blue-400" />
              <span className="text-sm text-gray-300">Geomagnetic Storm</span>
            </div>
            <span className={`text-sm font-semibold ${getStatusColor(weather.geomagneticStorm)}`}>
              {getStatusText(weather.geomagneticStorm)}
            </span>
          </div>
          <div className="flex space-x-1">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className={`h-2 flex-1 rounded ${
                  i < weather.geomagneticStorm ? 'bg-blue-400' : 'bg-gray-600'
                }`}
              ></div>
            ))}
          </div>
        </div>

        <div className="bg-white/5 rounded-xl p-4 border border-white/10">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-4 w-4 text-red-400" />
              <span className="text-sm text-gray-300">Radiation Level</span>
            </div>
            <span className={`text-sm font-semibold ${getStatusColor(weather.radiationLevel)}`}>
              {getStatusText(weather.radiationLevel)}
            </span>
          </div>
          <div className="flex space-x-1">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className={`h-2 flex-1 rounded ${
                  i < weather.radiationLevel ? 'bg-red-400' : 'bg-gray-600'
                }`}
              ></div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white/5 rounded-xl p-3 border border-white/10 text-center">
            <div className="text-lg font-bold text-purple-400">
              {weather.kpIndex.toFixed(1)}
            </div>
            <div className="text-xs text-gray-400">KP Index</div>
          </div>
          <div className="bg-white/5 rounded-xl p-3 border border-white/10 text-center">
            <div className="text-lg font-bold text-cyan-400">
              {weather.solarWindSpeed.toFixed(0)}
            </div>
            <div className="text-xs text-gray-400">km/s Wind</div>
          </div>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-white/10">
        <div className="text-xs text-gray-400 text-center">
          Data from NOAA Space Weather Prediction Center
        </div>
      </div>
    </div>
  );
};
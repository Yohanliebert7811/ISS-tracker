import React, { useRef, useEffect, useState } from 'react';
import { Canvas, useFrame, useLoader } from '@react-three/fiber';
import { OrbitControls, Stars, Text } from '@react-three/drei';
import * as THREE from 'three';
import { fetchISSPosition } from '../services/issApi';
import { ISSPosition } from '../types/iss';

const Earth: React.FC<{ issPosition: ISSPosition | null }> = ({ issPosition }) => {
  const earthRef = useRef<THREE.Mesh>(null);
  const issRef = useRef<THREE.Mesh>(null);
  const orbitRef = useRef<THREE.Line>(null);

  // Create Earth texture
  const earthTexture = new THREE.TextureLoader().load(
    'https://images.pexels.com/photos/87009/earth-blue-planet-globe-planet-87009.jpeg'
  );

  // Create orbit path
  const orbitPoints = [];
  for (let i = 0; i <= 360; i += 5) {
    const angle = (i * Math.PI) / 180;
    const radius = 6.771; // Earth radius + ISS altitude
    orbitPoints.push(new THREE.Vector3(
      radius * Math.cos(angle),
      0,
      radius * Math.sin(angle)
    ));
  }
  const orbitGeometry = new THREE.BufferGeometry().setFromPoints(orbitPoints);

  useFrame((state) => {
    if (earthRef.current) {
      earthRef.current.rotation.y += 0.002;
    }
    
    if (issRef.current && issPosition) {
      // Convert lat/lon to 3D coordinates
      const lat = parseFloat(issPosition.latitude) * Math.PI / 180;
      const lon = parseFloat(issPosition.longitude) * Math.PI / 180;
      const radius = 6.771;
      
      issRef.current.position.set(
        radius * Math.cos(lat) * Math.cos(lon),
        radius * Math.sin(lat),
        radius * Math.cos(lat) * Math.sin(lon)
      );
    }
  });

  return (
    <group>
      {/* Earth */}
      <mesh ref={earthRef}>
        <sphereGeometry args={[6.371, 64, 64]} />
        <meshPhongMaterial map={earthTexture} />
      </mesh>
      
      {/* Atmosphere */}
      <mesh>
        <sphereGeometry args={[6.5, 64, 64]} />
        <meshPhongMaterial 
          color={0x5599ff} 
          transparent 
          opacity={0.1} 
          side={THREE.BackSide}
        />
      </mesh>
      
      {/* ISS Orbit */}
      <line ref={orbitRef}>
        <bufferGeometry attach="geometry" {...orbitGeometry} />
        <lineBasicMaterial attach="material" color={0x00ff00} opacity={0.6} transparent />
      </line>
      
      {/* ISS */}
      {issPosition && (
        <mesh ref={issRef}>
          <boxGeometry args={[0.1, 0.1, 0.1]} />
          <meshBasicMaterial color={0xff0000} />
        </mesh>
      )}
      
      {/* ISS Label */}
      {issPosition && (
        <Text
          position={[7, 7, 0]}
          fontSize={0.5}
          color="white"
          anchorX="center"
          anchorY="middle"
        >
          ISS
        </Text>
      )}
    </group>
  );
};

export const Earth3D: React.FC = () => {
  const [issPosition, setIssPosition] = useState<ISSPosition | null>(null);

  useEffect(() => {
    const updatePosition = async () => {
      try {
        const position = await fetchISSPosition();
        setIssPosition(position);
      } catch (error) {
        console.error('Failed to fetch ISS position:', error);
      }
    };

    updatePosition();
    const interval = setInterval(updatePosition, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Canvas camera={{ position: [15, 5, 15], fov: 60 }}>
      <ambientLight intensity={0.3} />
      <pointLight position={[10, 10, 10]} intensity={1} />
      <Stars radius={300} depth={60} count={20000} factor={7} saturation={0} fade />
      <Earth issPosition={issPosition} />
      <OrbitControls enablePan={true} enableZoom={true} enableRotate={true} />
    </Canvas>
  );
};
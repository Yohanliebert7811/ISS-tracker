import React, { useEffect, useState } from 'react';
import { Satellite, Gauge, Clock, MapPin, Zap, Thermometer } from 'lucide-react';
import { ISSPosition } from '../types/iss';
import { fetchISSPosition } from '../services/issApi';

interface TelemetryData extends ISSPosition {
  altitude: number;
  velocity: number;
  solarPanelAngle: number;
  batteryLevel: number;
  temperature: number;
  crewCount: number;
}

export const TelemetryPanel: React.FC = () => {
  const [telemetry, setTelemetry] = useState<TelemetryData | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  useEffect(() => {
    const updateTelemetry = async () => {
      try {
        const position = await fetchISSPosition();
        // Simulate additional telemetry data
        setTelemetry({
          ...position,
          altitude: 408 + Math.random() * 10 - 5, // 408km ± 5km
          velocity: 27.6 + Math.random() * 0.2 - 0.1, // ~27.6 km/h ± 0.1
          solarPanelAngle: Math.random() * 360,
          batteryLevel: 85 + Math.random() * 15,
          temperature: 20 + Math.random() * 5,
          crewCount: 7
        });
        setLastUpdate(new Date());
      } catch (error) {
        console.error('Failed to fetch telemetry:', error);
      }
    };

    updateTelemetry();
    const interval = setInterval(updateTelemetry, 2000);
    return () => clearInterval(interval);
  }, []);

  if (!telemetry) {
    return (
      <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-white/10 rounded"></div>
          <div className="grid grid-cols-2 gap-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-20 bg-white/10 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const telemetryItems = [
    {
      icon: MapPin,
      label: 'Latitude',
      value: `${parseFloat(telemetry.latitude).toFixed(4)}°`,
      color: 'text-blue-400'
    },
    {
      icon: MapPin,
      label: 'Longitude',
      value: `${parseFloat(telemetry.longitude).toFixed(4)}°`,
      color: 'text-purple-400'
    },
    {
      icon: Gauge,
      label: 'Altitude',
      value: `${telemetry.altitude.toFixed(1)} km`,
      color: 'text-orange-400'
    },
    {
      icon: Zap,
      label: 'Velocity',
      value: `${telemetry.velocity.toFixed(1)} km/s`,
      color: 'text-green-400'
    },
    {
      icon: Thermometer,
      label: 'Temperature',
      value: `${telemetry.temperature.toFixed(1)}°C`,
      color: 'text-red-400'
    },
    {
      icon: Satellite,
      label: 'Crew',
      value: `${telemetry.crewCount} astronauts`,
      color: 'text-cyan-400'
    }
  ];

  return (
    <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-6 transition-all duration-300 hover:border-white/20">
      <div className="flex items-center space-x-3 mb-6">
        <Satellite className="h-6 w-6 text-blue-400" />
        <h2 className="text-xl font-semibold">ISS Telemetry</h2>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-sm text-green-400">Live</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {telemetryItems.map((item, index) => (
          <div key={index} className="bg-white/5 rounded-xl p-4 border border-white/10 hover:bg-white/10 transition-colors duration-200">
            <div className="flex items-center space-x-2 mb-2">
              <item.icon className={`h-4 w-4 ${item.color}`} />
              <span className="text-sm text-gray-300">{item.label}</span>
            </div>
            <div className="text-lg font-bold text-white">
              {item.value}
            </div>
          </div>
        ))}
      </div>

      {/* Battery and Solar Panel Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div className="bg-white/5 rounded-xl p-4 border border-white/10">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-300">Battery Level</span>
            <span className="text-sm text-green-400">{telemetry.batteryLevel.toFixed(0)}%</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-green-500 to-green-400 h-2 rounded-full transition-all duration-500"
              style={{ width: `${telemetry.batteryLevel}%` }}
            ></div>
          </div>
        </div>

        <div className="bg-white/5 rounded-xl p-4 border border-white/10">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-300">Solar Panel Angle</span>
            <span className="text-sm text-orange-400">{telemetry.solarPanelAngle.toFixed(0)}°</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-orange-400 rounded transform transition-transform duration-1000"
                 style={{ transform: `rotate(${telemetry.solarPanelAngle}deg)` }}>
            </div>
            <span className="text-xs text-gray-400">Tracking Sun</span>
          </div>
        </div>
      </div>

      <div className="pt-4 border-t border-white/10">
        <div className="flex items-center justify-between text-sm text-gray-400">
          <span>Last updated: {lastUpdate.toLocaleTimeString()}</span>
          <span>Orbital period: ~93 minutes</span>
        </div>
      </div>
    </div>
  );
};
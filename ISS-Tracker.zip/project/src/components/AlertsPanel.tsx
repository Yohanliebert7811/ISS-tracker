import React, { useState, useEffect } from 'react';
import { AlertTriangle, Satellite, Clock } from 'lucide-react';

interface Alert {
  id: string;
  type: 'debris' | 'weather' | 'system';
  severity: 'low' | 'medium' | 'high';
  message: string;
  timestamp: Date;
  distance?: number;
}

export const AlertsPanel: React.FC = () => {
  const [alerts, setAlerts] = useState<Alert[]>([
    {
      id: '1',
      type: 'debris',
      severity: 'medium',
      message: 'Space debris detected',
      timestamp: new Date(Date.now() - 5 * 60 * 1000),
      distance: 2.4
    },
    {
      id: '2',
      type: 'weather',
      severity: 'low',
      message: 'Solar flare activity increased',
      timestamp: new Date(Date.now() - 15 * 60 * 1000)
    }
  ]);

  useEffect(() => {
    const generateAlert = () => {
      const alertTypes = ['debris', 'weather', 'system'] as const;
      const severities = ['low', 'medium', 'high'] as const;
      const messages = [
        'Micrometeorite shower detected',
        'Communication satellite approaching',
        'Solar panel efficiency decreased',
        'Orbital debris tracked',
        'Geomagnetic storm warning'
      ];

      if (Math.random() < 0.3) { // 30% chance every 30 seconds
        const newAlert: Alert = {
          id: Date.now().toString(),
          type: alertTypes[Math.floor(Math.random() * alertTypes.length)],
          severity: severities[Math.floor(Math.random() * severities.length)],
          message: messages[Math.floor(Math.random() * messages.length)],
          timestamp: new Date(),
          distance: Math.random() < 0.5 ? Math.random() * 10 + 0.5 : undefined
        };

        setAlerts(prev => [newAlert, ...prev.slice(0, 4)]);
      }
    };

    const interval = setInterval(generateAlert, 30000);
    return () => clearInterval(interval);
  }, []);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'border-red-500 bg-red-500/10 text-red-400';
      case 'medium': return 'border-yellow-500 bg-yellow-500/10 text-yellow-400';
      default: return 'border-green-500 bg-green-500/10 text-green-400';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'debris': return Satellite;
      case 'weather': return AlertTriangle;
      default: return Clock;
    }
  };

  return (
    <div className="bg-black/20 backdrop-blur-md rounded-2xl border border-white/10 p-6 transition-all duration-300 hover:border-white/20">
      <div className="flex items-center space-x-3 mb-6">
        <AlertTriangle className="h-6 w-6 text-orange-400" />
        <h2 className="text-xl font-semibold">Mission Alerts</h2>
      </div>

      <div className="space-y-3 max-h-64 overflow-y-auto">
        {alerts.map((alert) => {
          const IconComponent = getTypeIcon(alert.type);
          return (
            <div
              key={alert.id}
              className={`p-3 rounded-xl border transition-all duration-200 hover:scale-[1.02] ${getSeverityColor(alert.severity)}`}
            >
              <div className="flex items-start space-x-3">
                <IconComponent className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start">
                    <p className="text-sm font-medium truncate">
                      {alert.message}
                    </p>
                    {alert.distance && (
                      <span className="text-xs ml-2 flex-shrink-0">
                        {alert.distance.toFixed(1)} km
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-xs opacity-75 capitalize">
                      {alert.type} • {alert.severity}
                    </span>
                    <span className="text-xs opacity-75">
                      {alert.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {alerts.length === 0 && (
        <div className="text-center py-8 text-gray-400">
          <AlertTriangle className="h-12 w-12 mx-auto mb-3 opacity-50" />
          <p>All systems nominal</p>
        </div>
      )}
    </div>
  );
};
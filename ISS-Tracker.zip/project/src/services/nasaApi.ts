import { APODData } from '../types/nasa';

const NASA_API_KEY = 'DEMO_KEY'; // In production, use environment variable

export const fetchAPOD = async (): Promise<APODData> => {
  try {
    const response = await fetch(
      `https://api.nasa.gov/planetary/apod?api_key=${NASA_API_KEY}`
    );
    const data = await response.json();
    
    if (data.error) {
      throw new Error(data.error.message);
    }
    
    return data;
  } catch (error) {
    // Fallback to a space image from Pexels
    return {
      title: 'Earth and Moon from Deep Space',
      url: 'https://images.pexels.com/photos/2166711/pexels-photo-2166711.jpeg',
      explanation: 'A stunning view of Earth and the Moon captured from deep space, showing the beautiful blue marble that is our home planet alongside its faithful companion.',
      date: new Date().toISOString().split('T')[0],
      media_type: 'image',
      copyright: 'NASA'
    };
  }
};
import { ISSPosition, ISSData } from '../types/iss';

export const fetchISSPosition = async (): Promise<ISSPosition> => {
  try {
    const response = await fetch('http://api.open-notify.org/iss-now.json');
    const data: ISSData = await response.json();
    
    if (data.message === 'success') {
      return {
        latitude: data.iss_position.latitude,
        longitude: data.iss_position.longitude,
        timestamp: data.timestamp
      };
    }
    
    throw new Error('Failed to fetch ISS position');
  } catch (error) {
    // Fallback position for demo
    return {
      latitude: '25.7617',
      longitude: '-80.1918',
      timestamp: Date.now() / 1000
    };
  }
};
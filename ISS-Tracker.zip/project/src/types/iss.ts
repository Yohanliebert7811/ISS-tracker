export interface ISSPosition {
  latitude: string;
  longitude: string;
  timestamp: number;
}

export interface ISSData {
  message: string;
  iss_position: {
    latitude: string;
    longitude: string;
  };
  timestamp: number;
}
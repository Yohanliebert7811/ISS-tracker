import React, { useState } from 'react';
import { Header } from './components/Header';
import { MissionControl } from './components/MissionControl';
import { Earth3D } from './components/Earth3D';
import { TelemetryPanel } from './components/TelemetryPanel';
import { OrbitAnalyzer } from './components/OrbitAnalyzer';
import { SpaceWeather } from './components/SpaceWeather';
import { APODSection } from './components/APODSection';
import { ParticleBackground } from './components/ParticleBackground';
import { QuantumCalculator } from './components/QuantumCalculator';
import { AISpaceWeather } from './components/AISpaceWeather';
import { BlockchainVerification } from './components/BlockchainVerification';
import { Monitor, Globe, BarChart3, Brain, Zap } from 'lucide-react';

type ViewMode = '3d' | 'dashboard' | 'analytics' | 'quantum' | 'ai';

function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('3d');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white relative overflow-hidden">
      <ParticleBackground />
      <div className="relative z-10">
        <Header />
        
        {/* View Mode Selector */}
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-center space-x-2 mb-6 overflow-x-auto">
            <button
              onClick={() => setViewMode('3d')}
              className={`flex items-center space-x-2 px-4 py-3 rounded-xl transition-all duration-300 whitespace-nowrap ${
                viewMode === '3d' 
                  ? 'bg-blue-500/30 border-2 border-blue-400 text-blue-300' 
                  : 'bg-white/5 border border-white/20 hover:bg-white/10'
              }`}
            >
              <Globe className="h-5 w-5" />
              <span>3D Mission Control</span>
            </button>
            <button
              onClick={() => setViewMode('dashboard')}
              className={`flex items-center space-x-2 px-4 py-3 rounded-xl transition-all duration-300 whitespace-nowrap ${
                viewMode === 'dashboard' 
                  ? 'bg-purple-500/30 border-2 border-purple-400 text-purple-300' 
                  : 'bg-white/5 border border-white/20 hover:bg-white/10'
              }`}
            >
              <Monitor className="h-5 w-5" />
              <span>Dashboard</span>
            </button>
            <button
              onClick={() => setViewMode('analytics')}
              className={`flex items-center space-x-2 px-4 py-3 rounded-xl transition-all duration-300 whitespace-nowrap ${
                viewMode === 'analytics' 
                  ? 'bg-green-500/30 border-2 border-green-400 text-green-300' 
                  : 'bg-white/5 border border-white/20 hover:bg-white/10'
              }`}
            >
              <BarChart3 className="h-5 w-5" />
              <span>Analytics</span>
            </button>
            <button
              onClick={() => setViewMode('quantum')}
              className={`flex items-center space-x-2 px-4 py-3 rounded-xl transition-all duration-300 whitespace-nowrap ${
                viewMode === 'quantum' 
                  ? 'bg-purple-500/30 border-2 border-purple-400 text-purple-300' 
                  : 'bg-white/5 border border-white/20 hover:bg-white/10'
              }`}
            >
              <Zap className="h-5 w-5" />
              <span>Quantum Lab</span>
            </button>
            <button
              onClick={() => setViewMode('ai')}
              className={`flex items-center space-x-2 px-4 py-3 rounded-xl transition-all duration-300 whitespace-nowrap ${
                viewMode === 'ai' 
                  ? 'bg-cyan-500/30 border-2 border-cyan-400 text-cyan-300' 
                  : 'bg-white/5 border border-white/20 hover:bg-white/10'
              }`}
            >
              <Brain className="h-5 w-5" />
              <span>AI Command</span>
            </button>
          </div>
        </div>

        <main className="container mx-auto px-4 pb-8">
          {viewMode === '3d' && <MissionControl />}
          {viewMode === 'dashboard' && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <TelemetryPanel />
                </div>
                <SpaceWeather />
              </div>
              <APODSection />
            </div>
          )}
          {viewMode === 'analytics' && <OrbitAnalyzer />}
          {viewMode === 'quantum' && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <QuantumCalculator />
                <BlockchainVerification />
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <TelemetryPanel />
                </div>
                <SpaceWeather />
              </div>
            </div>
          )}
          {viewMode === 'ai' && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <AISpaceWeather />
                <BlockchainVerification />
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <TelemetryPanel />
                </div>
                <QuantumCalculator />
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

export default App;
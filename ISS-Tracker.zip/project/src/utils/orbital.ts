// Orbital mechanics calculations based on Kepler's laws
export const calculateOrbitPeriod = (altitudeKm: number) => {
  // Constants
  const EARTH_RADIUS_KM = 6371; // Earth's radius in km
  const G = 6.67430e-11; // Gravitational constant in m³/kg⋅s²
  const EARTH_MASS_KG = 5.972e24; // Earth's mass in kg
  
  // Convert to meters
  const radiusM = (EARTH_RADIUS_KM + altitudeKm) * 1000;
  
  // Calculate orbital period using Kepler's third law
  // T = 2π√(r³/GM)
  const periodSeconds = 2 * Math.PI * Math.sqrt(Math.pow(radiusM, 3) / (G * EARTH_MASS_KG));
  const periodHours = periodSeconds / 3600;
  
  // Calculate orbital velocity
  // v = √(GM/r)
  const velocityMs = Math.sqrt((G * EARTH_MASS_KG) / radiusM);
  const velocityKms = velocityMs / 1000;
  
  return {
    period: periodHours,
    velocity: velocityKms
  };
};

export const calculateEscapeVelocity = (altitudeKm: number) => {
  const EARTH_RADIUS_KM = 6371;
  const G = 6.67430e-11;
  const EARTH_MASS_KG = 5.972e24;
  
  const radiusM = (EARTH_RADIUS_KM + altitudeKm) * 1000;
  const escapeVelocityMs = Math.sqrt((2 * G * EARTH_MASS_KG) / radiusM);
  
  return escapeVelocityMs / 1000; // km/s
};